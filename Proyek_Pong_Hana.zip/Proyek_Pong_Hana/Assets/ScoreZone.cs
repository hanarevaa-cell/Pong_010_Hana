using UnityEngine;

public class ScoreZone : MonoBehaviour
{
    GameManager manager;

    void Start() {
        // Mencari objek Game Manager di dalam scene
        manager = Object.FindFirstObjectByType<GameManager>();
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if (other.CompareTag("Ball")) {
            if (gameObject.CompareTag("PlayerZone")) {
                GameManager.instance.OpponentWin(); 
            } else if (gameObject.CompareTag("OpponentZone")) {
                GameManager.instance.PlayerWin();  
            }
        }
    }
}