using UnityEngine;

public class Player : MonoBehaviour
{
    // [SerializeField] diletakkan DI SINI (di luar fungsi) agar tidak error
    [SerializeField] float speed = 5f; 

    Rigidbody2D rb;
    Vector2 movementVector;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Membaca input vertikal (W/S atau Panah)
        movementVector = new Vector2(0, Input.GetAxisRaw("Vertical"));
    }

    void FixedUpdate()
    {
        // Menggerakkan posisi fisik bet
        rb.transform.position += (Vector3)movementVector * speed * Time.fixedDeltaTime;
    }
}