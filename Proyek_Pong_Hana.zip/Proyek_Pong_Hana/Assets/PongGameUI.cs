using UnityEngine;
using TMPro;

public class PongGameUI : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI playerScoreLabel;
    [SerializeField] TextMeshProUGUI opponentScoreLabel;
    GameManager manager;

    void Start() {
        manager = Object.FindFirstObjectByType<GameManager>();
    }

    public void UpdatePlayerScore() {
        playerScoreLabel.SetText(manager.playerScore.ToString());
    }

    public void UpdateOpponentScore() {
        opponentScoreLabel.SetText(manager.opponentScore.ToString());
    }
}