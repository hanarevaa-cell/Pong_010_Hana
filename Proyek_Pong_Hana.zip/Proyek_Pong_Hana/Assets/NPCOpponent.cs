using UnityEngine;

public class NPCOpponent : MonoBehaviour
{
    //setting kecepatan
    [SerializeField] float minSpeed = 5f;
    [SerializeField] float maxSpeed = 8f;

    Rigidbody2D rb;
    PongBall ball;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        // Mencari objek bola di dalam game
        ball = Object.FindFirstObjectByType<PongBall>(); 
    }

    void FixedUpdate()
    {
        if (ball != null)
        {
            // Memberikan variasi kecepatan agar gerakan lebih dinamis
            float speed = Random.Range(minSpeed, maxSpeed);
            Vector3 ballPosition = ball.transform.position;
            
            // Mengikuti posisi Y bola (naik/turun)
            rb.transform.position = Vector3.Lerp(transform.position, 
                new Vector3(transform.position.x, ballPosition.y, 0), 
                Time.fixedDeltaTime * speed);
        }
    }
}