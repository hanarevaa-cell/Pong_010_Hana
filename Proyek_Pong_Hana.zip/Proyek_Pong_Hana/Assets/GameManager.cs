using UnityEngine;
using UnityEngine.Events; 

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [Header("Skor Terkini")]
    public int playerScore = 0;
    public int opponentScore = 0;

    [Header("Pengaturan UI & Bola")]
    public UnityEvent playerWin;
    public UnityEvent opponentWin;
    public PongBall ball; // Pastikan objek PongBall ditarik ke sini di Inspector

    void Awake()
    {
        if (instance == null) instance = this;
        else Destroy(gameObject);
    }

    // Fungsi utama tambah skor
    public void AddScore(bool playerLost)
    {
        if (playerLost)
        {
            opponentScore++;
            opponentWin.Invoke(); 
        }
        else
        {
            playerScore++;
            playerWin.Invoke(); 
        }

        // Memunculkan bola lagi di tengah
        if (ball != null) 
        {
            ball.ThrowBall(); 
        }

        // Cek Pemenang sesuai aturan (Skor 11)
        if (playerScore >= 11 || opponentScore >= 11)
        {
            Debug.Log("Game Over! Skor Akhir: " + playerScore + " - " + opponentScore);
            // Kamu bisa tambahkan logika restart game di sini kalau mau
        }
    }

    // Fungsi bantuan agar script ScoreZone bisa memanggil dengan mudah
    public void PlayerWin() 
    {
        AddScore(false); 
    }

    public void OpponentWin() 
    {
        AddScore(true); 
    }
}