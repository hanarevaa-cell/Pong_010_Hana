using UnityEngine;

public class PongBall : MonoBehaviour
{
    [SerializeField] float force = 100f;

    Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        ThrowBall();
    }

    public void ThrowBall()
    {
        // Reset posisi ke tengah layar
        transform.position = Vector2.zero;
        // Memberikan gaya dorong ke arah acak
        rb.AddForce(GenerateRandomDirection() * force);
    }

    private Vector2 GenerateRandomDirection()
    {
        // Menentukan sudut acak 360 derajat
        float randomValue = Random.Range(0f, 360f);
        return new Vector2(Mathf.Cos(randomValue), Mathf.Sin(randomValue));
    }
}